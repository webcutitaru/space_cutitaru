import { CartErrorEvent, CartLinesUpdateEvent } from '@shopify/events';

class CartUpsell extends HTMLElement {
  /** @type {boolean} */
  #adding = false;

  connectedCallback() {
    this.querySelector('[data-cart-upsell-add]')?.addEventListener('click', this.#onAdd);
  }

  disconnectedCallback() {
    this.querySelector('[data-cart-upsell-add]')?.removeEventListener('click', this.#onAdd);
  }

  /** @param {Event} event */
  #onAdd = (event) => {
    event.preventDefault();
    event.stopPropagation();
    const id = this.dataset.variantId || '';
    if (!id) return;
    this.#add(id);
  };

  /** @param {string} id */
  async #add(id) {
    if (this.#adding) return;
    this.#adding = true;

    const button = this.querySelector('[data-cart-upsell-add]');
    const wasDisabled = button instanceof HTMLButtonElement && button.disabled;
    if (button instanceof HTMLButtonElement) button.disabled = true;
    this.#showError('');

    const sectionIds = [...document.querySelectorAll('cart-items-component')]
      .map((item) => (item instanceof HTMLElement ? item.dataset.sectionId : ''))
      .filter(Boolean);

    const deferred = CartLinesUpdateEvent.createPromise();
    this.dispatchEvent(
      new CartLinesUpdateEvent({
        action: 'add',
        context: 'cart',
        lines: [{ merchandiseId: id, quantity: 1 }],
        detail: { source: 'cart-upsell' },
        promise: deferred.promise,
      })
    );

    try {
      const response = await fetch(Theme.routes.cart_add_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          items: [{ id: Number(id), quantity: 1 }],
          sections: sectionIds.join(','),
        }),
      });
      const added = await response.json();

      if (added.status) {
        const message = added.description || added.message || 'Could not add this product.';
        this.#showError(message);
        this.dispatchEvent(
          new CartErrorEvent({
            error: message,
            code: 'INVALID',
            detail: { description: added.description, errors: added.errors },
          })
        );
        deferred.reject(new Error(message));
        return;
      }

      const cartItems = document.querySelector('cart-items-component');
      const cart = cartItems?.fetchCartData
        ? await cartItems.fetchCartData()
        : await fetch(`${Theme.routes.cart_url}.json`, {
            headers: { Accept: 'application/json' },
            credentials: 'same-origin',
          }).then((result) => result.json());

      deferred.resolve({
        cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
        detail: {
          items: cart.items,
          sections: added.sections,
          didError: false,
          itemCount: 1,
          source: 'cart-upsell',
        },
      });
    } catch (error) {
      const message = error?.message || 'Could not add this product.';
      this.#showError(message);
      deferred.reject(error);
      this.dispatchEvent(
        new CartErrorEvent({
          error: message,
          code: 'SERVICE_UNAVAILABLE',
        })
      );
    } finally {
      this.#adding = false;
      if (button instanceof HTMLButtonElement) button.disabled = wasDisabled;
    }
  }

  /** @param {string} message */
  #showError(message) {
    const error = this.querySelector('[data-cart-upsell-error]');
    if (!(error instanceof HTMLElement)) return;
    error.hidden = message === '';
    error.textContent = message;
  }
}

if (!customElements.get('cart-upsell')) {
  customElements.define('cart-upsell', CartUpsell);
}
