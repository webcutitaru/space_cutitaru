const MOBILE = window.matchMedia('(max-width: 749px)');
const REDUCE = window.matchMedia('(prefers-reduced-motion: reduce)');

class ImageVideoSliderPro extends HTMLElement {
  /** @type {number} */
  #index = 0;

  /** @type {number} */
  #shift = 0;

  /** @type {AbortController | undefined} */
  #abort;

  /** @type {ReturnType<typeof setInterval> | undefined} */
  #timer;

  /** @type {{ type: string, per: number, scroll: number, gap: number, peek: number, flush: boolean, adaptive: boolean, drag: string, center: boolean }} */
  #config = {
    type: 'classic',
    per: 1,
    scroll: 1,
    gap: 0,
    peek: 0,
    flush: false,
    adaptive: false,
    drag: 'enabled',
    center: false,
  };

  /** @type {{ slideWidth: number, gap: number, peek: number, per: number, count: number, origin: number, maxIndex: number, points: number[] }} */
  #metrics = {
    slideWidth: 0,
    gap: 0,
    peek: 0,
    per: 1,
    count: 0,
    origin: 0,
    maxIndex: 0,
    points: [0],
  };

  /** @type {number} */
  #width = 0;

  /** @type {boolean} */
  #mobile = false;

  /** @type {boolean} */
  #moved = false;

  connectedCallback() {
    if (this.dataset.ready === 'true') return;
    this.dataset.ready = 'true';
    this.#width = 0;
    this.#abort = new AbortController();
    const { signal } = this.#abort;

    this.addEventListener('click', this.#onClick, { signal });
    this.addEventListener('pointerdown', this.#onPointerDown, { signal });
    this.addEventListener('pointerenter', () => this.#stopAutoplay(), { signal });
    this.addEventListener('pointerleave', () => this.#startAutoplay(), { signal });
    this.addEventListener('keydown', this.#onKey, { signal });
    this.querySelector('[data-track]')?.addEventListener('transitionend', this.#onTransitionEnd, { signal });

    MOBILE.addEventListener('change', this.#layout, { signal });
    const viewport = this.querySelector('[data-viewport]');
    if (viewport && 'ResizeObserver' in window) {
      const observer = new ResizeObserver(() => this.#layout());
      observer.observe(viewport);
      signal.addEventListener('abort', () => observer.disconnect());
    }

    this.#layout();
    this.#startAutoplay();
  }

  disconnectedCallback() {
    this.#stopAutoplay();
    this.#abort?.abort();
    this.dataset.ready = 'false';
  }

  /** @param {MouseEvent} event */
  #onClick = (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    if (this.#moved) {
      event.preventDefault();
      event.stopPropagation();
      this.#moved = false;
      return;
    }

    if (target.closest('[data-prev]')) {
      event.preventDefault();
      this.#step(-1);
    } else if (target.closest('[data-next]')) {
      event.preventDefault();
      this.#step(1);
    } else if (target.closest('[data-dot]')) {
      const dot = target.closest('[data-dot]');
      const index = Number(dot instanceof HTMLElement ? dot.dataset.index : '');
      if (!Number.isNaN(index)) this.#go(index, 0, true);
    }
  };

  /** @param {KeyboardEvent} event */
  #onKey = (event) => {
    if (event.key === 'ArrowLeft') this.#step(-1);
    if (event.key === 'ArrowRight') this.#step(1);
  };

  /** @param {PointerEvent} event */
  #onPointerDown = (event) => {
    if (this.#config.drag === 'disabled') return;
    if (!(event.target instanceof Element) || event.target.closest('button')) return;
    if (event.pointerType === 'mouse' && event.button !== 0) return;

    const viewport = this.querySelector('[data-viewport]');
    const track = this.querySelector('[data-track]');
    if (!(viewport instanceof HTMLElement) || !(track instanceof HTMLElement)) return;

    const startX = event.clientX;
    const startY = event.clientY;
    const startTranslate = this.#currentX();
    let dragging = false;
    this.#moved = false;
    this.#stopAutoplay();

    const move = (pointerEvent) => {
      const dx = pointerEvent.clientX - startX;
      const dy = pointerEvent.clientY - startY;
      if (!dragging) {
        if (Math.abs(dx) < 6 || Math.abs(dx) < Math.abs(dy)) return;
        dragging = true;
        this.#moved = true;
        viewport.setPointerCapture(pointerEvent.pointerId);
      }
      pointerEvent.preventDefault();
      if (this.#config.type === 'fade') return;
      track.style.transition = 'none';
      track.style.transform = `translate3d(${this.#clampX(startTranslate + dx)}px, 0, 0)`;
    };

    const up = (pointerEvent) => {
      viewport.removeEventListener('pointermove', move);
      viewport.removeEventListener('pointerup', up);
      viewport.removeEventListener('pointercancel', up);
      if (!dragging) {
        this.#startAutoplay();
        return;
      }
      const dx = pointerEvent.clientX - startX;
      if (this.#config.type === 'fade') {
        if (dx < -40) this.#step(1);
        else if (dx > 40) this.#step(-1);
      } else if (this.#config.drag === 'free') {
        this.#settleFree(this.#clampX(startTranslate + dx));
      } else {
        this.#snapToNearest(this.#clampX(startTranslate + dx));
      }
      window.setTimeout(() => {
        this.#moved = false;
      }, 50);
      this.#startAutoplay();
    };

    viewport.addEventListener('pointermove', move);
    viewport.addEventListener('pointerup', up);
    viewport.addEventListener('pointercancel', up);
  };

  /** @param {TransitionEvent} event */
  #onTransitionEnd = (event) => {
    if (event.propertyName !== 'transform' || event.target !== this.querySelector('[data-track]')) return;
    if (this.#shift === 0 || this.#config.type !== 'infinite') return;
    this.#go(this.#index, 0, false);
  };

  #layout = () => {
    const viewport = this.querySelector('[data-viewport]');
    const track = this.querySelector('[data-track]');
    if (!(viewport instanceof HTMLElement) || !(track instanceof HTMLElement)) return;

    const width = viewport.clientWidth;
    if (!width) return;
    const mobile = MOBILE.matches;
    if (width === this.#width && mobile === this.#mobile && this.#metrics.count) return;
    this.#width = width;
    this.#mobile = mobile;

    this.#config = this.#readConfig();
    this.#clearClones();
    const reals = this.#realSlides();
    const count = reals.length;
    if (!count) return;

    const infinite = this.#config.type === 'infinite' && count > 1;
    if (infinite) {
      const before = document.createDocumentFragment();
      const after = document.createDocumentFragment();
      reals.forEach((slide) => {
        before.append(this.#clone(slide));
        after.append(this.#clone(slide));
      });
      track.prepend(before);
      track.append(after);
    }

    const per = Math.min(this.#config.per, count);
    const gap = this.#config.gap;
    const peek = this.#config.type === 'fade' ? 0 : this.#config.peek;
    const slideWidth = Math.max(1, (width - peek * 2 - gap * Math.max(0, per - 1)) / per);
    const maxIndex = this.#config.type === 'fade' ? count - 1 : Math.max(0, count - per);
    const scroll = Math.max(1, Math.min(this.#config.scroll, per));

    /** @type {number[]} */
    const points = [];
    if (maxIndex === 0) {
      points.push(0);
    } else {
      for (let i = 0; i <= maxIndex; i += scroll) points.push(i);
      if (points[points.length - 1] !== maxIndex) points.push(maxIndex);
    }

    this.#metrics = {
      slideWidth,
      gap,
      peek,
      per,
      count,
      origin: infinite ? count : 0,
      maxIndex,
      points,
    };

    track.style.gap = `${gap}px`;
    [...track.children].forEach((slide) => {
      if (slide instanceof HTMLElement) slide.style.width = `${slideWidth}px`;
    });

    this.classList.toggle('ivs-pro--adaptive', this.#config.adaptive && per === 1 && this.#config.drag !== 'free');
    this.classList.toggle('ivs-pro--center-on', this.#config.center && per > 1 && this.#config.type !== 'fade');

    if (this.#index > maxIndex) this.#index = maxIndex;
    if (this.#index < 0) this.#index = 0;
    this.#shift = 0;
    this.#paintDots();
    this.#go(this.#index, 0, false);
  };

  #readConfig() {
    const mobile = MOBILE.matches;
    const prefix = mobile ? 'mobile' : 'desktop';
    const dataset = /** @type {DOMStringMap} */ (this.dataset);
    const per = Number(dataset[`${prefix}Per`]) || 1;
    const type = dataset.type || 'classic';
    return {
      type,
      per: type === 'fade' ? 1 : per,
      scroll: Number(dataset[`${prefix}Scroll`]) || 1,
      gap: Number(dataset[`${prefix}Gap`]) || 0,
      peek: Number(dataset[`${prefix}Peek`]) || 0,
      flush: dataset[`${prefix}Flush`] === 'true',
      adaptive: dataset[`${prefix}Adaptive`] === 'true',
      drag: dataset.drag || 'enabled',
      center: dataset.center === 'true',
    };
  }

  #realSlides() {
    const track = this.querySelector('[data-track]');
    if (!track) return [];
    return [...track.querySelectorAll('[data-slide]:not([data-clone])')].filter((slide) => slide instanceof HTMLElement);
  }

  #clearClones() {
    this.querySelectorAll('[data-clone]').forEach((node) => node.remove());
  }

  /** @param {HTMLElement} slide */
  #clone(slide) {
    const copy = slide.cloneNode(true);
    if (!(copy instanceof HTMLElement)) return document.createElement('div');
    copy.dataset.clone = 'true';
    [...copy.attributes].forEach((attr) => {
      if (attr.name.startsWith('data-shopify')) copy.removeAttribute(attr.name);
    });
    return copy;
  }

  /**
   * @param {number} index
   * @param {number} shift
   */
  #translateFor(index, shift) {
    const { slideWidth, gap, peek, origin, maxIndex } = this.#metrics;
    const step = slideWidth + gap;
    if (this.#config.type === 'infinite') {
      return peek - (origin + shift + index) * step;
    }
    let lead = peek;
    if (this.#config.flush && peek > 0 && this.#config.type === 'classic') {
      if (index <= 0) lead = 0;
      else if (index >= maxIndex) lead = peek * 2;
    }
    return lead - index * step;
  }

  /** @param {number} x */
  #clampX(x) {
    if (this.#config.type === 'infinite' || this.#config.type === 'fade') return x;
    const start = this.#translateFor(0, 0);
    const end = this.#translateFor(this.#metrics.maxIndex, 0);
    return Math.min(start, Math.max(end, x));
  }

  #currentX() {
    const track = this.querySelector('[data-track]');
    if (!(track instanceof HTMLElement)) return 0;
    const value = track.style.transform;
    const match = value.match(/translate3d\(([-\d.]+)px/);
    if (match) return Number(match[1]);
    return this.#translateFor(this.#index, this.#shift);
  }

  /**
   * @param {number} index
   * @param {number} shift
   * @param {boolean} animate
   */
  #go(index, shift, animate) {
    const max = this.#metrics.maxIndex;
    if (this.#config.type === 'classic') {
      index = Math.max(0, Math.min(max, index));
      shift = 0;
    } else if (this.#config.type === 'fade') {
      const count = this.#metrics.count || 1;
      index = ((index % count) + count) % count;
      shift = 0;
    } else {
      const count = this.#metrics.count || 1;
      while (index < 0) {
        index += count;
        shift -= count;
      }
      while (index >= count) {
        index -= count;
        shift += count;
      }
      if (!animate) shift = 0;
    }

    this.#index = index;
    this.#shift = shift;
    this.#mark();
    this.#updateArrows();
    this.#paintCurrentDot();

    const track = this.querySelector('[data-track]');
    if (!(track instanceof HTMLElement) || this.#config.type === 'fade') return;
    const reduce = REDUCE.matches;
    track.style.transition = animate && !reduce ? 'transform 0.45s ease' : 'none';
    track.style.transform = `translate3d(${this.#translateFor(index, shift)}px, 0, 0)`;
  }

  /** @param {number} direction */
  #step(direction) {
    const scroll = Math.max(1, Math.min(this.#config.scroll, this.#metrics.per));
    if (this.#config.type === 'classic') {
      const fallback = direction > 0 ? this.#metrics.maxIndex : 0;
      const target = direction > 0
        ? this.#metrics.points.find((point) => point >= this.#index + scroll) ?? fallback
        : [...this.#metrics.points].reverse().find((point) => point <= this.#index - scroll) ?? fallback;
      this.#go(target, 0, true);
      return;
    }
    this.#go(this.#index + direction * scroll, this.#shift, true);
  }

  /** @param {number} x */
  #snapToNearest(x) {
    let bestIndex = this.#index;
    let bestShift = 0;
    let bestDist = Infinity;
    const shifts = this.#config.type === 'infinite' ? [0, this.#metrics.count, -this.#metrics.count] : [0];
    for (const point of this.#metrics.points) {
      for (const shift of shifts) {
        const dist = Math.abs(this.#translateFor(point, shift) - x);
        if (dist < bestDist) {
          bestDist = dist;
          bestIndex = point;
          bestShift = shift;
        }
      }
    }
    this.#go(bestIndex, bestShift, true);
  }

  /** @param {number} x */
  #settleFree(x) {
    const track = this.querySelector('[data-track]');
    if (!(track instanceof HTMLElement)) return;
    let next = x;
    if (this.#config.type === 'infinite') {
      const span = this.#metrics.count * (this.#metrics.slideWidth + this.#metrics.gap);
      const home = this.#translateFor(this.#index, 0);
      while (next < home - span) next += span;
      while (next > home + span) next -= span;
    }
    track.style.transition = 'none';
    track.style.transform = `translate3d(${next}px, 0, 0)`;
  }

  #mark() {
    const nodes = [...(this.querySelector('[data-track]')?.children || [])];
    nodes.forEach((node) => node.classList.remove('is-center', 'is-shown', 'is-active'));
    if (this.#config.type === 'fade') {
      const real = this.#realSlides();
      real[this.#index]?.classList.add('is-active', 'is-shown');
      this.#syncMedia();
      return;
    }
    const start = this.#metrics.origin + this.#shift + this.#index;
    const centerAt = start + Math.floor((this.#metrics.per - 1) / 2);
    nodes.forEach((node, i) => {
      if (i >= start && i < start + this.#metrics.per) node.classList.add('is-shown');
      if (this.#config.center && this.#metrics.per > 1 && i === centerAt) node.classList.add('is-center');
    });
    this.#syncMedia();
  }

  #syncMedia() {
    this.querySelectorAll('video').forEach((video) => {
      if (!(video instanceof HTMLVideoElement)) return;
      const slide = video.closest('[data-slide]');
      if (slide instanceof HTMLElement && slide.classList.contains('is-shown')) {
        video.play().catch(() => {});
      } else {
        video.pause();
      }
    });
  }

  #updateArrows() {
    const atStart = this.#config.type === 'classic' && this.#index <= 0;
    const atEnd = this.#config.type === 'classic' && this.#index >= this.#metrics.maxIndex;
    this.querySelectorAll('[data-prev]').forEach((button) => {
      if (button instanceof HTMLButtonElement) button.disabled = atStart;
    });
    this.querySelectorAll('[data-next]').forEach((button) => {
      if (button instanceof HTMLButtonElement) button.disabled = atEnd;
    });
  }

  #paintDots() {
    const dots = this.querySelector('[data-dots]');
    if (!(dots instanceof HTMLElement)) return;
    dots.replaceChildren();
    if (this.#metrics.points.length < 2) return;
    this.#metrics.points.forEach((point) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'ivs-pro__dot';
      button.dataset.dot = '';
      button.dataset.index = String(point);
      button.setAttribute('aria-label', `Slide ${point + 1}`);
      dots.append(button);
    });
    this.#paintCurrentDot();
  }

  #paintCurrentDot() {
    const current = this.#metrics.points.includes(this.#index)
      ? this.#index
      : this.#metrics.points.reduce((nearest, point) =>
          Math.abs(point - this.#index) < Math.abs(nearest - this.#index) ? point : nearest
        , this.#metrics.points[0]);
    this.querySelectorAll('[data-dot]').forEach((dot) => {
      if (!(dot instanceof HTMLElement)) return;
      if (Number(dot.dataset.index) === current) dot.setAttribute('aria-current', 'true');
      else dot.removeAttribute('aria-current');
    });
  }

  #startAutoplay() {
    this.#stopAutoplay();
    if (this.dataset.autoplay !== 'true' || this.#metrics.points.length < 2) return;
    const seconds = Number(this.dataset.autoplaySpeed) || 5;
    this.#timer = setInterval(() => {
      if (document.hidden) return;
      this.#step(1);
    }, seconds * 1000);
  }

  #stopAutoplay() {
    if (this.#timer) clearInterval(this.#timer);
    this.#timer = undefined;
  }
}

if (!customElements.get('image-video-slider-pro')) {
  customElements.define('image-video-slider-pro', ImageVideoSliderPro);
}
