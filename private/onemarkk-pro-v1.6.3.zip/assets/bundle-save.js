import { CartErrorEvent, CartLinesUpdateEvent, StandardEvents } from '@shopify/events';
import { QuantitySelectorUpdateEvent, ThemeEvents } from '@theme/events';

const MONEY_PLACEHOLDER = /\{\{\s*(\w+)\s*\}\}/;

/**
 * @param {number} cents
 * @param {number} precision
 * @param {string} thousands
 * @param {string} decimal
 */
function formatWithDelimiters(cents, precision, thousands, decimal) {
  const amount = (cents / 100).toFixed(precision);
  const parts = amount.split('.');
  const whole = parts[0].replace(/(\d)(?=(\d{3})+(?!\d))/g, `$1${thousands}`);
  return parts[1] ? `${whole}${decimal}${parts[1]}` : whole;
}

/**
 * @param {number} cents
 * @param {string} format
 */
function formatMoney(cents, format) {
  const plain = format.replace(/<[^>]*>/g, '');
  format = plain || format;
  const zeroDecimal = format.includes('no_decimals');
  const value = zeroDecimal ? Math.round(cents) * 100 : cents;
  const formats = {
    amount: formatWithDelimiters(value, 2, ',', '.'),
    amount_no_decimals: formatWithDelimiters(value, 0, ',', '.'),
    amount_with_comma_separator: formatWithDelimiters(value, 2, '.', ','),
    amount_no_decimals_with_comma_separator: formatWithDelimiters(value, 0, '.', ','),
    amount_with_apostrophe_separator: formatWithDelimiters(value, 2, "'", '.'),
    amount_no_decimals_with_space_separator: formatWithDelimiters(value, 0, ' ', '.'),
    amount_with_space_separator: formatWithDelimiters(value, 2, ' ', ','),
    amount_with_period_and_space_separator: formatWithDelimiters(value, 2, ' ', '.'),
  };
  const match = format.match(MONEY_PLACEHOLDER);
  const formatted = match ? formats[match[1]] ?? formats.amount : formats.amount;
  return format.replace(MONEY_PLACEHOLDER, formatted);
}

class BundleSave extends HTMLElement {
  /** @type {Array<{id: number, title: string, price: number, compare: number, available: boolean, options: string[]}>} */
  variants = [];

  /** @type {Array<{name: string, values: string[]}>} */
  options = [];

  /** @type {boolean} */
  #syncing = false;

  /** @type {boolean} */
  #adding = false;

  /** @type {AbortController | undefined} */
  #abort;

  connectedCallback() {
    if (this.dataset.ready === 'true') return;
    this.dataset.ready = 'true';

    const data = this.querySelector('[data-bundle-variants]');
    const options = this.querySelector('[data-bundle-options]');
    this.variants = data?.textContent ? JSON.parse(data.textContent) : [];
    this.options = options?.textContent ? JSON.parse(options.textContent) : [];
    this.#abort = new AbortController();
    const signal = this.#abort.signal;
    const section = this.closest('.shopify-section');

    this.addEventListener('change', this.#onChange, { signal });
    // The theme listens for submit on document during capture, which is before
    // any section listener. Window capture runs first, so the bundle can set
    // the quantity or take over a mixed-variant add before Add to cart starts.
    window.addEventListener('submit', this.#onSubmit, { capture: true, signal });
    section?.addEventListener(StandardEvents.productSelect, this.#onVariant, { signal });
    document.addEventListener(ThemeEvents.quantitySelectorUpdate, this.#onQuantity, { signal });

    this.#renderVariantSelects();
    this.#hideQuantity();
    this.#syncFromSelection();
    requestAnimationFrame(() => this.#syncFromSelection());
  }

  disconnectedCallback() {
    this.#abort?.abort();
    delete this.dataset.ready;
  }

  /** @param {Event} event */
  #onChange = (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement) || !this.contains(target)) return;

    if (target instanceof HTMLInputElement && target.type === 'radio') {
      this.#renderVariantSelects();
      this.#syncFromSelection();
      return;
    }

    if (target instanceof HTMLSelectElement) {
      this.#syncFromSelection();
    }
  };

  /** @param {Event} event */
  #onQuantity = (event) => {
    if (this.#syncing) return;
    const section = this.closest('.shopify-section');
    if (!(event.target instanceof Node) || !section?.contains(event.target)) return;

    const quantity = Number(/** @type {CustomEvent} */ (event).detail?.quantity);
    if (!Number.isFinite(quantity)) return;

    const match = [...this.querySelectorAll('.bundle-save__card')].find(
      (card) => Number(card.getAttribute('data-quantity')) === quantity
    );

    for (const input of this.querySelectorAll('input[type="radio"]')) {
      if (input instanceof HTMLInputElement) input.checked = false;
    }

    const radio = match?.querySelector('input[type="radio"]');
    if (radio instanceof HTMLInputElement) radio.checked = true;
    this.#renderVariantSelects();
  };

  /** @param {Event} event */
  #onVariant = (event) => {
    if (!(event.target instanceof Element) || event.target.closest('product-card')) return;

    const productEvent = /** @type {import('@shopify/events').ProductSelectEvent} */ (event);
    productEvent.promise
      ?.then(({ detail }) => {
        const resource = detail?.resource;
        if (!resource?.id) return;
        if (detail.productId && String(detail.productId) !== String(this.dataset.productId)) return;

        this.dataset.currentVariant = String(resource.id);
        const found = this.variants.find((variant) => String(variant.id) === String(resource.id));
        if (found) {
          if (resource.price != null) found.price = resource.price;
          if (resource.compare_at_price != null) found.compare = resource.compare_at_price;
          if (resource.available != null) found.available = resource.available;
          if (resource.title) found.title = resource.title;
        }

        if (this.dataset.priceUpdates === 'true') this.#renderPrices();
        this.#renderVariantSelects({ reset: true });
        this.#hideQuantity();
        this.#syncFromSelection();
        window.setTimeout(() => this.#syncFromSelection(), 0);
        window.setTimeout(() => this.#syncFromSelection(), 120);
      })
      .catch((error) => {
        if (error?.name !== 'AbortError') console.warn('[bundle-save] Variant update failed:', error);
      });
  };

  #ownsForm() {
    return this.closest('.shopify-section')?.querySelector('bundle-save') === this;
  }

  /** @param {Event} event */
  #onSubmit = (event) => {
    if (!this.#ownsForm()) return;
    const form = this.#form();
    if (!form || event.target !== form) return;

    const groups = this.#groups();
    if (!groups?.length) return;

    const quantity = groups.reduce((sum, group) => sum + group.quantity, 0);
    this.#writeQuantity(quantity);
    this.#syncAcceleratedCheckout(groups.length > 1);

    if (groups.length === 1) {
      this.#setVariantId(groups[0].id);
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    this.#addLines(groups);
  };

  #syncFromSelection() {
    if (!this.#ownsForm()) return;
    const groups = this.#groups();
    if (!groups?.length) {
      this.#syncAcceleratedCheckout(false);
      return;
    }
    this.#writeQuantity(groups.reduce((sum, group) => sum + group.quantity, 0));
    if (groups.length === 1) this.#setVariantId(groups[0].id);
    this.#syncAcceleratedCheckout(groups.length > 1);
  }

  /** Shop Pay buys only the form variant, so it stays hidden for a mixed bundle. */
  #syncAcceleratedCheckout(mixed) {
    const block = this.#form()?.querySelector('.accelerated-checkout-block');
    if (!(block instanceof HTMLElement)) return;

    if (mixed) {
      if (!block.hasAttribute('data-bundle-hidden')) {
        block.dataset.bundleWasHidden = block.hidden ? 'true' : 'false';
        block.setAttribute('data-bundle-hidden', '');
      }
      block.hidden = true;
      return;
    }

    if (!block.hasAttribute('data-bundle-hidden')) return;
    block.hidden = block.dataset.bundleWasHidden === 'true';
    block.removeAttribute('data-bundle-hidden');
    delete block.dataset.bundleWasHidden;
  }

  /** @returns {Record<string, unknown>} */
  #lineExtras() {
    const form = this.#form();
    if (!form) return {};

    const data = new FormData(form);
    /** @type {Record<string, unknown>} */
    const extras = {};
    const sellingPlan = data.get('selling_plan');
    if (typeof sellingPlan === 'string' && sellingPlan !== '') extras.selling_plan = Number(sellingPlan);

    /** @type {Record<string, string>} */
    const properties = {};
    for (const [key, value] of data.entries()) {
      if (typeof value !== 'string' || value === '') continue;
      const match = key.match(/^properties\[(.*)\]$/);
      if (match) properties[match[1]] = value;
    }
    if (Object.keys(properties).length > 0) extras.properties = properties;
    return extras;
  }

  #hideQuantity() {
    if (!this.#ownsForm()) return;
    const wrapper = this.#form()?.querySelector('.quantity-selector-wrapper');
    wrapper?.classList.toggle('bundle-save-qty-hidden', this.dataset.hideQuantity === 'true');
  }

  /**
   * @param {{ reset?: boolean }} [options]
   */
  #renderVariantSelects({ reset = false } = {}) {
    const multiple = this.dataset.defaultVariant !== 'true' && this.variants.length > 1;
    const enabled = this.dataset.variantSelectors === 'true' && multiple && this.options.length > 0;
    const current = this.#currentVariant();

    for (const card of this.querySelectorAll('.bundle-save__card')) {
      const slot = card.querySelector('[data-variant-slots]');
      if (!(slot instanceof HTMLElement)) continue;

      const radio = card.querySelector('input[type="radio"]');
      const checked = radio instanceof HTMLInputElement && radio.checked;
      const quantity = Number(card.getAttribute('data-quantity'));
      const show = enabled && checked && (quantity > 1 || this.dataset.variantSelectorsSingle === 'true');
      const previous = reset
        ? []
        : [...slot.querySelectorAll('[data-unit]')].map((unit) =>
            [...unit.querySelectorAll('select')].map((select) => select.value)
          );

      slot.replaceChildren();
      if (!show) continue;

      for (let index = 0; index < quantity; index += 1) {
        const unit = document.createElement('div');
        unit.className = 'bundle-save__unit';
        unit.dataset.unit = String(index);

        const label = document.createElement('span');
        label.className = 'bundle-save__unit-index';
        label.textContent = `#${index + 1}`;
        unit.append(label);

        const chosen = previous[index]?.length ? previous[index] : current?.options || [];
        this.options.forEach((option, optionIndex) => {
          const wrap = document.createElement('span');
          wrap.className = 'bundle-save__select-wrap';
          const select = document.createElement('select');
          select.className = 'bundle-save__select';
          select.dataset.optionIndex = String(optionIndex);
          select.setAttribute('aria-label', `${label.textContent} ${option.name}`);

          for (const value of this.#optionValues(optionIndex, chosen)) {
            const choice = document.createElement('option');
            choice.value = value;
            choice.textContent = value;
            select.append(choice);
          }

          const preferred = chosen[optionIndex];
          if (preferred && [...select.options].some((item) => item.value === preferred)) {
            select.value = preferred;
          }
          wrap.append(select);
          unit.append(wrap);
        });

        slot.append(unit);
      }
    }
  }

  /**
   * @param {number} optionIndex
   * @param {string[]} chosen
   */
  #optionValues(optionIndex, chosen) {
    const hideSoldOut = this.dataset.hideSoldOut === 'true';
    const values = new Set();

    for (const variant of this.variants) {
      if (hideSoldOut && !variant.available) continue;
      const matches = variant.options.every((value, index) => index === optionIndex || !chosen[index] || value === chosen[index]);
      if (matches && variant.options[optionIndex]) values.add(variant.options[optionIndex]);
    }

    const listed = this.options[optionIndex]?.values || [];
    const available = listed.filter((value) => values.has(value));
    return available.length ? available : [...values];
  }

  #renderPrices() {
    const variant = this.#currentVariant();
    if (!variant) return;
    const format = this.dataset.moneyFormat || '{{amount}}';

    for (const card of this.querySelectorAll('.bundle-save__card')) {
      if (!(card instanceof HTMLElement)) continue;
      const quote = this.#quote(card, variant);
      const sale = card.querySelector('.bundle-save__sale');
      if (sale) sale.textContent = formatMoney(quote.sale, format);

      let compare = card.querySelector('.bundle-save__compare');
      if (quote.compare > quote.sale) {
        if (!compare) {
          compare = document.createElement('s');
          compare.className = 'bundle-save__compare';
          card.querySelector('.bundle-save__prices')?.append(compare);
        }
        compare.textContent = formatMoney(quote.compare, format);
      } else {
        compare?.remove();
      }

      const caption = card.querySelector('.bundle-save__caption');
      const template = card.dataset.captionTemplate || '';
      if (caption) {
        const rounded = this.#roundMoney(quote.saved);
        caption.textContent = template
          .replaceAll('[amount_saved_rounded]', formatMoney(rounded, format))
          .replaceAll('[amount_saved]', formatMoney(quote.saved, format));
      }
    }
  }

  /**
   * @param {HTMLElement} card
   * @param {{ price: number, compare: number }} variant
   */
  #quote(card, variant) {
    const quantity = Number(card.dataset.quantity) || 0;
    const percent = Math.min(100, Math.max(0, Number(card.dataset.percent) || 0));
    const line = variant.price * quantity;
    let sale = Math.round((line * (100 - percent)) / 100) - this.#fixedCents(card.dataset.fixed || '0');
    if (sale < 0) sale = 0;

    const compareUnit = card.dataset.compareBasis === 'compare' && variant.compare > 0 ? variant.compare : variant.price;
    const compare = compareUnit * quantity;
    return { sale, compare, saved: Math.max(0, compare - sale) };
  }

  /** @param {string} raw */
  #fixedCents(raw) {
    const major = Number.parseFloat(raw.replace(',', '.'));
    if (!Number.isFinite(major)) return 0;
    const zeroDecimal = (this.dataset.moneyFormat || '').includes('no_decimals');
    return Math.round(major * (zeroDecimal ? 1 : 100));
  }

  /** @param {number} cents */
  #roundMoney(cents) {
    const zeroDecimal = (this.dataset.moneyFormat || '').includes('no_decimals');
    if (zeroDecimal) return cents;
    return Math.round(cents / 100) * 100;
  }

  #currentVariant() {
    return (
      this.variants.find((variant) => String(variant.id) === String(this.dataset.currentVariant)) || this.variants[0]
    );
  }

  /** @returns {{ id: string, quantity: number }[] | null} */
  #groups() {
    const card = this.querySelector('.bundle-save__card:has(input:checked)');
    if (!(card instanceof HTMLElement)) return null;

    const units = [...card.querySelectorAll('[data-unit]')];
    if (units.length === 0) {
      const id = this.#variantInput()?.value || this.dataset.currentVariant;
      if (!id) return null;
      return [{ id: String(id), quantity: Number(card.dataset.quantity) || 1 }];
    }

    /** @type {Map<string, number>} */
    const counts = new Map();
    for (const unit of units) {
      const variant = this.#variantFromUnit(unit);
      if (!variant) continue;
      const id = String(variant.id);
      counts.set(id, (counts.get(id) || 0) + 1);
    }

    if (counts.size === 0) {
      return [{ id: String(this.dataset.currentVariant), quantity: Number(card.dataset.quantity) || 1 }];
    }

    return [...counts].map(([id, quantity]) => ({ id, quantity }));
  }

  /** @param {Element} unit */
  #variantFromUnit(unit) {
    const chosen = [...unit.querySelectorAll('select')].map((select) =>
      select instanceof HTMLSelectElement ? select.value : ''
    );
    return this.variants.find(
      (variant) => variant.available !== false && variant.options.every((value, index) => value === chosen[index])
    ) || this.variants.find((variant) => variant.options.every((value, index) => value === chosen[index]));
  }

  /** @param {number} quantity */
  #writeQuantity(quantity) {
    const form = this.#form();
    if (!form || !quantity) return;

    const selector = this.#quantitySelector();
    const selectorInput = selector?.querySelector('input[name="quantity"]');
    if (selectorInput instanceof HTMLInputElement && !selectorInput.disabled) {
      selectorInput.value = String(quantity);
      this.#syncing = true;
      try {
        if (selector?.setValue) selector.setValue(String(quantity));
        selector?.dispatchEvent(new QuantitySelectorUpdateEvent(quantity));
      } finally {
        this.#syncing = false;
      }
      form.querySelector('input[data-bundle-quantity]')?.remove();
      return;
    }

    let input = form.querySelector('input[data-bundle-quantity]');
    if (!(input instanceof HTMLInputElement)) {
      input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'quantity';
      input.setAttribute('data-bundle-quantity', 'true');
      form.append(input);
    }
    input.value = String(quantity);
  }

  /** @param {string} id */
  #setVariantId(id) {
    const input = this.#variantInput();
    if (input) input.value = String(id);
  }

  /** @param {{ id: string, quantity: number }[]} groups */
  async #addLines(groups) {
    if (this.#adding) return;
    this.#adding = true;

    const button = this.#form()?.querySelector('.add-to-cart-button');
    const wasDisabled = button instanceof HTMLButtonElement && button.disabled;
    if (button instanceof HTMLButtonElement) button.disabled = true;
    this.#showError('');

    const sectionIds = [...document.querySelectorAll('cart-items-component')]
      .map((item) => (item instanceof HTMLElement ? item.dataset.sectionId : ''))
      .filter(Boolean);

    const itemCount = groups.reduce((sum, group) => sum + group.quantity, 0);
    const deferred = CartLinesUpdateEvent.createPromise();

    this.dispatchEvent(
      new CartLinesUpdateEvent({
        action: 'add',
        context: 'product',
        lines: groups.map((group) => ({
          merchandiseId: group.id,
          quantity: group.quantity,
        })),
        promise: deferred.promise,
      })
    );

    try {
      const response = await fetch(Theme.routes.cart_add_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          items: groups.map((group) => ({
            id: Number(group.id),
            quantity: group.quantity,
            ...this.#lineExtras(),
          })),
          sections: sectionIds.join(','),
        }),
      });
      const added = await response.json();

      if (added.status) {
        const message = added.description || added.message || 'Could not add these items to the cart.';
        this.#showError(message);
        this.dispatchEvent(
          new CartErrorEvent({
            error: message,
            code: 'INVALID',
            detail: { description: added.description, errors: added.errors },
          })
        );
        deferred.reject(new Error(message));
        return;
      }

      const cartItems = document.querySelector('cart-items-component');
      const cart = cartItems?.fetchCartData
        ? await cartItems.fetchCartData()
        : await fetch(`${Theme.routes.cart_url}.json`, {
            headers: { Accept: 'application/json' },
            credentials: 'same-origin',
          }).then((result) => result.json());

      deferred.resolve({
        cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
        detail: {
          items: cart.items,
          sections: added.sections,
          didError: false,
          itemCount,
          source: 'bundle-save',
        },
      });

      const quantityInput = this.#quantitySelector()?.querySelector('input[name="quantity"]');
      if (quantityInput instanceof HTMLInputElement && Array.isArray(cart.items)) {
        const variantId = this.#variantInput()?.value;
        const inCart = cart.items
          .filter((item) => String(item.variant_id) === String(variantId))
          .reduce((sum, item) => sum + item.quantity, 0);
        quantityInput.setAttribute('data-cart-quantity', String(inCart));
        this.#quantitySelector()?.updateCartQuantity?.();
      }
    } catch (error) {
      const message = error?.message || 'Could not add these items to the cart.';
      this.#showError(message);
      deferred.reject(error);
      this.dispatchEvent(
        new CartErrorEvent({
          error: message,
          code: 'SERVICE_UNAVAILABLE',
        })
      );
    } finally {
      this.#adding = false;
      if (button instanceof HTMLButtonElement) button.disabled = wasDisabled;
    }
  }

  /** @param {string} message */
  #showError(message) {
    const error = this.querySelector('[data-bundle-error]');
    if (!(error instanceof HTMLElement)) return;
    error.hidden = message === '';
    error.textContent = message;
  }

  #form() {
    return this.closest('.shopify-section')?.querySelector('product-form-component form[data-type="add-to-cart-form"]');
  }

  #variantInput() {
    return this.#form()?.querySelector('input[name="id"]');
  }

  #quantitySelector() {
    const selector = this.#form()?.querySelector('quantity-selector-component');
    if (!selector) return null;
    return /** @type {HTMLElement & { setValue?: (value: string) => void, updateCartQuantity?: () => void }} */ (
      selector
    );
  }
}

if (!customElements.get('bundle-save')) {
  customElements.define('bundle-save', BundleSave);
}
