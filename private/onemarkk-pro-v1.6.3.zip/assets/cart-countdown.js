const STORAGE_KEY = 'onemarkk-cart-countdown';

class CartCountdown extends HTMLElement {
  /** @type {number | undefined} */
  #timer;

  /** @type {number} */
  #ends = NaN;

  /** @type {() => void} */
  #onCartUpdate = () => {
    if (this.#timer !== undefined) return;
    this.#ends = NaN;
    this.#start();
  };

  connectedCallback() {
    document.addEventListener('cart:lines-update', this.#onCartUpdate);
    this.#start();
  }

  disconnectedCallback() {
    document.removeEventListener('cart:lines-update', this.#onCartUpdate);
    this.#stop();
  }

  #start() {
    this.#stop();
    if (!this.#tick()) return;
    this.#timer = window.setInterval(() => this.#tick(), 1000);
  }

  #stop() {
    if (this.#timer === undefined) return;
    window.clearInterval(this.#timer);
    this.#timer = undefined;
  }

  #tick() {
    const time = this.querySelector('[data-countdown-time]');
    if (!(time instanceof HTMLElement)) return true;

    const end = this.#endTime();
    if (!Number.isFinite(end)) return false;

    const remaining = Math.max(0, Math.floor((end - Date.now()) / 1000));
    const minutes = Math.floor(remaining / 60);
    const seconds = remaining % 60;
    time.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    if (remaining <= 0) {
      this.#stop();
      return false;
    }

    return true;
  }

  /** @returns {number} */
  #endTime() {
    if (Number.isFinite(this.#ends)) return this.#ends;

    const minutes = Number(this.dataset.minutes);
    if (!Number.isFinite(minutes) || minutes <= 0) return NaN;

    const stored = this.#read();
    const storedIsLive =
      stored &&
      stored.minutes === minutes &&
      Number.isFinite(stored.ends) &&
      stored.ends > Date.now();
    const ends = storedIsLive ? stored.ends : Date.now() + minutes * 60 * 1000;

    if (!storedIsLive) this.#write({ minutes, ends });
    this.#ends = ends;
    return ends;
  }

  /** @returns {{ minutes: number, ends: number } | null} */
  #read() {
    try {
      const parsed = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || '');
      if (!parsed || typeof parsed !== 'object') return null;
      return { minutes: Number(parsed.minutes), ends: Number(parsed.ends) };
    } catch {
      return null;
    }
  }

  /** @param {{ minutes: number, ends: number }} value */
  #write(value) {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(value));
    } catch {
      /* Private browsing can block storage. The timer still runs for this view. */
    }
  }
}

if (!customElements.get('cart-countdown')) {
  customElements.define('cart-countdown', CartCountdown);
}
