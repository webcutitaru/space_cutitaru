import { CartErrorEvent, CartLinesUpdateEvent, StandardEvents } from '@shopify/events';

const MONEY_PLACEHOLDER = /\{\{\s*(\w+)\s*\}\}/;

/**
 * @param {number} cents
 * @param {number} precision
 * @param {string} thousands
 * @param {string} decimal
 */
function formatWithDelimiters(cents, precision, thousands, decimal) {
  const amount = (cents / 100).toFixed(precision);
  const parts = amount.split('.');
  const whole = parts[0].replace(/(\d)(?=(\d{3})+(?!\d))/g, `$1${thousands}`);
  return parts[1] ? `${whole}${decimal}${parts[1]}` : whole;
}

/**
 * @param {number} cents
 * @param {string} format
 */
function formatMoney(cents, format) {
  const plain = format.replace(/<[^>]*>/g, '');
  format = plain || format;
  const zeroDecimal = format.includes('no_decimals');
  const value = zeroDecimal ? Math.round(cents) * 100 : cents;
  const formats = {
    amount: formatWithDelimiters(value, 2, ',', '.'),
    amount_no_decimals: formatWithDelimiters(value, 0, ',', '.'),
    amount_with_comma_separator: formatWithDelimiters(value, 2, '.', ','),
    amount_no_decimals_with_comma_separator: formatWithDelimiters(value, 0, '.', ','),
    amount_with_apostrophe_separator: formatWithDelimiters(value, 2, "'", '.'),
    amount_no_decimals_with_space_separator: formatWithDelimiters(value, 0, ' ', '.'),
    amount_with_space_separator: formatWithDelimiters(value, 2, ' ', ','),
    amount_with_period_and_space_separator: formatWithDelimiters(value, 2, ' ', '.'),
  };
  const match = format.match(MONEY_PLACEHOLDER);
  const formatted = match ? formats[match[1]] ?? formats.amount : formats.amount;
  return format.replace(MONEY_PLACEHOLDER, formatted);
}

class ProductUpsells extends HTMLElement {
  /** @type {boolean} */
  #adding = false;

  /** @type {number} */
  #lastAdd = 0;

  /** @type {AbortController | undefined} */
  #abort;

  connectedCallback() {
    if (this.dataset.ready === 'true') return;
    this.dataset.ready = 'true';
    this.#abort = new AbortController();
    const { signal } = this.#abort;

    this.addEventListener('change', this.#onChange, { signal });
    this.addEventListener('click', this.#onClick, { signal });
    document.addEventListener(StandardEvents.cartLinesUpdate, this.#onCart, { signal });

    if (this.dataset.source === 'recommendations') {
      this.#loadRecommendations();
    } else {
      this.querySelectorAll('[data-upsell]').forEach((row) => {
        if (row instanceof HTMLElement) this.#syncRow(row, false);
      });
    }
  }

  disconnectedCallback() {
    this.#abort?.abort();
    this.dataset.ready = 'false';
  }

  /** @param {Event} event */
  #onChange = (event) => {
    const select = event.target;
    if (!(select instanceof HTMLSelectElement)) return;
    const row = select.closest('[data-upsell]');
    if (!(row instanceof HTMLElement)) return;
    this.#syncRow(row, true);
  };

  /** @param {MouseEvent} event */
  #onClick = (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    const add = target.closest('[data-upsell-add]');
    if (add instanceof HTMLButtonElement) {
      event.preventDefault();
      const row = add.closest('[data-upsell]');
      const id = row instanceof HTMLElement ? row.dataset.variantId : '';
      if (id) this.#addLines([{ id, quantity: 1 }]);
      return;
    }

    if (this.dataset.clickTarget !== 'row') return;
    const row = target.closest('[data-upsell]');
    if (!(row instanceof HTMLElement) || !this.contains(row)) return;
    if (target.closest('a, select, button, label, input')) return;
    row.querySelector('[data-upsell-toggle]')?.click();
  };

  /**
   * @param {Event & { action?: string, context?: string, promise?: Promise<unknown>, lines?: { merchandiseId?: string }[], detail?: { source?: string } }} event
   */
  #onCart = (event) => {
    if (this.#adding) return;
    if (event.detail?.source === 'product-upsells') return;
    if (event.action !== 'add' || event.context !== 'product') return;

    const lines = this.#selectedLines(event.lines);
    if (!lines.length) return;
    if (Date.now() - this.#lastAdd < 1500) return;
    this.#lastAdd = Date.now();

    const run = () => {
      this.#addLines(lines);
    };

    if (event.promise instanceof Promise) {
      event.promise.then(run).catch(() => {});
    } else {
      run();
    }
  };

  async #loadRecommendations() {
    const productId = this.dataset.productId;
    const base = this.dataset.recommendationsUrl;
    if (!productId || !base) return;

    try {
      const url = `${base}.json?product_id=${productId}&limit=4&intent=related`;
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      if (!response.ok) return;
      const payload = await response.json();
      const products = Array.isArray(payload.products) ? payload.products : [];
      const list = this.querySelector('[data-upsell-list]');
      if (!(list instanceof HTMLElement)) return;

      let shown = 0;
      for (const product of products) {
        if (shown >= 3) break;
        if (String(product.id) === String(productId)) continue;
        const row = this.#rowFromRecommendation(product);
        if (!row) continue;
        list.append(row);
        this.#syncRow(row, false);
        shown += 1;
      }
    } catch (error) {
      console.warn('[product-upsells] Recommendations failed:', error);
    }
  }

  /**
   * @param {Record<string, any>} product
   */
  #rowFromRecommendation(product) {
    const variants = Array.isArray(product.variants) ? product.variants : [];
    const hideSoldOut = this.dataset.hideSoldOut === 'true';
    const availableVariants = variants.filter((variant) => variant.available);
    if (hideSoldOut && availableVariants.length === 0) return null;

    const optionNames = (Array.isArray(product.options) ? product.options : []).map((option) =>
      typeof option === 'string' ? option : option?.name || 'Option'
    );
    const normalized = {
      percent: 0,
      fixedCents: 0,
      options: optionNames.map((name, index) => ({
        name,
        values: [...new Set(variants.map((variant) => variant[`option${index + 1}`]).filter(Boolean))],
      })),
      variants: variants.map((variant) => ({
        id: variant.id,
        price: variant.price,
        compare: variant.compare_at_price || 0,
        available: Boolean(variant.available),
        options: [variant.option1, variant.option2, variant.option3].filter((value) => value && value !== 'Default Title'),
      })),
    };

    const chosen = (hideSoldOut ? availableVariants[0] : variants[0]) || variants[0];
    if (!chosen) return null;

    const article = document.createElement('article');
    article.className = 'product-upsells__item';
    article.dataset.upsell = '';
    article.dataset.variantId = String(chosen.id);

    const image = this.#imageUrl(product.featured_image) || this.#imageUrl(chosen.featured_image);
    if (image && !this.classList.contains('product-upsells--no-images')) {
      const media = document.createElement('div');
      media.className = 'product-upsells__media';
      const img = document.createElement('img');
      img.className = 'product-upsells__image';
      img.alt = product.title || '';
      img.src = image;
      img.loading = 'lazy';
      media.append(img);
      article.append(media);
    }

    const main = document.createElement('div');
    main.className = 'product-upsells__main';
    const headline = document.createElement('div');
    headline.className = `product-upsells__headline${this.dataset.pricePosition === 'below' ? ' product-upsells__headline--below' : ''}`;
    const titleText = product.title || '';
    const title =
      this.dataset.titleLink === 'true' && product.url
        ? document.createElement('a')
        : document.createElement('p');
    title.className = 'product-upsells__title';
    title.textContent = titleText;
    if (title instanceof HTMLAnchorElement) title.href = product.url;
    const prices = document.createElement('p');
    prices.className = 'product-upsells__prices';
    const price = document.createElement('span');
    price.className = 'product-upsells__price';
    price.dataset.upsellPrice = '';
    const compare = document.createElement('s');
    compare.className = 'product-upsells__compare';
    compare.dataset.upsellCompare = '';
    compare.hidden = true;
    prices.append(price, compare);
    headline.append(title, prices);
    main.append(headline);

    if (normalized.options.some((option) => option.values.length > 1)) {
      const options = document.createElement('div');
      options.className = 'product-upsells__options';
      normalized.options.forEach((option, optionIndex) => {
        if (option.values.length < 1) return;
        const wrap = document.createElement('label');
        wrap.className = 'product-upsells__select-wrap';
        const select = document.createElement('select');
        select.dataset.optionIndex = String(optionIndex);
        select.setAttribute('aria-label', option.name || 'Option');
        for (const value of option.values) {
          const choice = document.createElement('option');
          choice.value = value;
          choice.textContent = value;
          if (chosen[`option${optionIndex + 1}`] === value) choice.selected = true;
          select.append(choice);
        }
        wrap.append(select);
        options.append(wrap);
      });
      if (options.childElementCount) main.append(options);
    }

    article.append(main);

    const action = document.createElement('div');
    action.className = 'product-upsells__action';
    if (this.dataset.toggleStyle === 'button') {
      const button = document.createElement('button');
      button.className = 'product-upsells__add';
      button.type = 'button';
      button.dataset.upsellAdd = '';
      button.textContent = 'Add';
      if (!chosen.available) button.disabled = true;
      action.append(button);
    } else {
      const label = document.createElement('label');
      label.className = 'product-upsells__switch';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.dataset.upsellToggle = '';
      input.setAttribute('aria-label', `Add ${product.title || 'product'}`);
      if (!chosen.available) input.disabled = true;
      const track = document.createElement('span');
      track.className = 'product-upsells__track';
      track.setAttribute('aria-hidden', 'true');
      label.append(input, track);
      action.append(label);
    }
    article.append(action);

    const data = document.createElement('script');
    data.type = 'application/json';
    data.dataset.upsellData = '';
    data.textContent = JSON.stringify(normalized);
    article.append(data);

    return article;
  }

  /**
   * @param {unknown} image
   */
  #imageUrl(image) {
    if (!image) return '';
    if (typeof image === 'string') return image;
    if (typeof image === 'object' && image && 'src' in image && typeof image.src === 'string') return image.src;
    return '';
  }

  /**
   * @param {HTMLElement} row
   * @param {boolean} fromUser
   */
  #syncRow(row, fromUser) {
    const data = this.#data(row);
    if (!data) return;

    const selects = [...row.querySelectorAll('select')];
    if (this.dataset.hideSoldOut === 'true') {
      const chosen = selects.map((select) => select.value);
      selects.forEach((select, optionIndex) => {
        const current = select.value;
        const values = this.#optionValues(data, optionIndex, chosen);
        const existing = [...select.options].map((option) => option.value);
        if (values.length && existing.join('|') !== values.join('|')) {
          select.replaceChildren(
            ...values.map((value) => {
              const option = document.createElement('option');
              option.value = value;
              option.textContent = value;
              return option;
            })
          );
          if (values.includes(current)) select.value = current;
        }
      });
    }

    const variant = this.#variantFromRow(row, data);
    if (!variant) return;
    row.dataset.variantId = String(variant.id);

    const toggle = row.querySelector('[data-upsell-toggle]');
    const add = row.querySelector('[data-upsell-add]');
    if (toggle instanceof HTMLInputElement) toggle.disabled = !variant.available;
    if (add instanceof HTMLButtonElement) add.disabled = !variant.available;

    if (!fromUser && this.dataset.priceUpdates === 'false') return;
    if (this.dataset.priceUpdates === 'false' && fromUser) return;
    this.#paintPrice(row, data, variant);
  }

  /**
   * @param {HTMLElement} row
   * @param {{ percent: number, fixedCents: number, variants: { id: number, price: number, compare: number, available: boolean, options: string[] }[] }} data
   * @param {{ price: number, compare: number }} variant
   */
  #paintPrice(row, data, variant) {
    const price = row.querySelector('[data-upsell-price]');
    const compare = row.querySelector('[data-upsell-compare]');
    const sale = this.#sale(variant.price, data.percent, data.fixedCents);
    if (price) price.textContent = formatMoney(sale, this.dataset.moneyFormat || '');

    const basis = variant.compare > variant.price ? variant.compare : variant.price;
    if (compare instanceof HTMLElement) {
      compare.hidden = this.dataset.hideCompare === 'true' || basis <= sale;
      compare.textContent = formatMoney(basis, this.dataset.moneyFormat || '');
    }
  }

  /**
   * @param {number} price
   * @param {number} percent
   * @param {number} fixedCents
   */
  #sale(price, percent, fixedCents) {
    const keep = 100 - (Number(percent) || 0);
    const sale = Math.round((price * keep) / 100) - (Number(fixedCents) || 0);
    return Math.max(0, sale);
  }

  /**
   * @param {HTMLElement} row
   */
  #data(row) {
    const script = row.querySelector('[data-upsell-data]');
    if (!script?.textContent) return null;
    try {
      return JSON.parse(script.textContent);
    } catch {
      return null;
    }
  }

  /**
   * @param {HTMLElement} row
   * @param {{ variants: { id: number, price: number, compare: number, available: boolean, options: string[] }[] }} data
   */
  #variantFromRow(row, data) {
    const chosen = [...row.querySelectorAll('select')].map((select) => select.value);
    if (!chosen.length) {
      return data.variants.find((variant) => variant.available) || data.variants[0];
    }
    return (
      data.variants.find((variant) => variant.available && variant.options.every((value, index) => !chosen[index] || value === chosen[index])) ||
      data.variants.find((variant) => variant.options.every((value, index) => !chosen[index] || value === chosen[index])) ||
      data.variants[0]
    );
  }

  /**
   * @param {{ variants: { available: boolean, options: string[] }[], options: { values: string[] }[] }} data
   * @param {number} optionIndex
   * @param {string[]} chosen
   */
  #optionValues(data, optionIndex, chosen) {
    const values = new Set();
    for (const variant of data.variants) {
      if (!variant.available) continue;
      const matches = variant.options.every((value, index) => index === optionIndex || !chosen[index] || value === chosen[index]);
      if (matches && variant.options[optionIndex]) values.add(variant.options[optionIndex]);
    }
    const listed = data.options[optionIndex]?.values || [];
    const available = listed.filter((value) => values.has(value));
    return available.length ? available : [...values];
  }

  /**
   * @param {{ merchandiseId?: string }[] | undefined} mainLines
   */
  #selectedLines(mainLines) {
    const mainIds = new Set((mainLines || []).map((line) => String(line.merchandiseId || '').split('/').pop()));
    /** @type {{ id: string, quantity: number }[]} */
    const items = [];

    this.querySelectorAll('[data-upsell]').forEach((row) => {
      if (!(row instanceof HTMLElement)) return;
      const toggle = row.querySelector('[data-upsell-toggle]');
      if (!(toggle instanceof HTMLInputElement) || !toggle.checked || toggle.disabled) return;
      const id = row.dataset.variantId || '';
      if (!id || mainIds.has(id) || items.some((item) => item.id === id)) return;
      items.push({ id, quantity: 1 });
    });

    return items;
  }

  /**
   * @param {{ id: string, quantity: number }[]} lines
   */
  async #addLines(lines) {
    if (!lines.length || this.#adding) return;
    this.#adding = true;
    this.#lastAdd = Date.now();
    this.#showError('');

    const sectionIds = [...document.querySelectorAll('cart-items-component')]
      .map((item) => (item instanceof HTMLElement ? item.dataset.sectionId : ''))
      .filter(Boolean);

    const deferred = CartLinesUpdateEvent.createPromise();
    this.dispatchEvent(
      new CartLinesUpdateEvent({
        action: 'add',
        context: 'product',
        lines: lines.map((line) => ({
          merchandiseId: line.id,
          quantity: line.quantity,
        })),
        detail: { source: 'product-upsells' },
        promise: deferred.promise,
      })
    );

    try {
      const response = await fetch(Theme.routes.cart_add_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          items: lines.map((line) => ({
            id: Number(line.id),
            quantity: line.quantity,
          })),
          sections: sectionIds.join(','),
        }),
      });
      const added = await response.json();

      if (added.status) {
        const message = added.description || added.message || 'Could not add this product.';
        this.#showError(message);
        this.dispatchEvent(
          new CartErrorEvent({
            error: message,
            code: 'INVALID',
            detail: { description: added.description, errors: added.errors },
          })
        );
        deferred.reject(new Error(message));
        return;
      }

      const cartItems = document.querySelector('cart-items-component');
      const cart = cartItems?.fetchCartData
        ? await cartItems.fetchCartData()
        : await fetch(`${Theme.routes.cart_url}.json`, {
            headers: { Accept: 'application/json' },
            credentials: 'same-origin',
          }).then((result) => result.json());

      deferred.resolve({
        cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
        detail: {
          items: cart.items,
          sections: added.sections,
          didError: false,
          itemCount: lines.length,
          source: 'product-upsells',
        },
      });
    } catch (error) {
      const message = error?.message || 'Could not add this product.';
      this.#showError(message);
      deferred.reject(error);
      this.dispatchEvent(
        new CartErrorEvent({
          error: message,
          code: 'SERVICE_UNAVAILABLE',
        })
      );
    } finally {
      this.#adding = false;
    }
  }

  /** @param {string} message */
  #showError(message) {
    const error = this.querySelector('[data-upsell-error]');
    if (!(error instanceof HTMLElement)) return;
    error.hidden = message === '';
    error.textContent = message;
  }
}

if (!customElements.get('product-upsells')) {
  customElements.define('product-upsells', ProductUpsells);
}
